import './App.css';
import * as React from 'react';
import { ResponsiveDrawer } from './sidebar';


function App() {
  return (
    <div className="App">
      <ResponsiveDrawer />
    </div>
  );
}

export default App;
